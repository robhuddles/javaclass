module com.murach.lineitem.app {
    requires com.murach;
}