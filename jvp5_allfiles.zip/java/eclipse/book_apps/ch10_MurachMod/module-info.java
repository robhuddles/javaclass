module com.murach {
    requires java.base;
    exports murach.business;
    exports murach.database;
    exports murach.presentation;
}