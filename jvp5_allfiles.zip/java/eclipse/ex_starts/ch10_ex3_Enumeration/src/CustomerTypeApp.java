public class CustomerTypeApp {

    public static void main(String[] args) {
        // display a welcome message
        System.out.println("Welcome to the Customer Type Test application\n");

        // get and display the discount percent for a customer type
        // display the value of the toString method of a customer type
    }

    // a method that accepts a CustomerType enumeration
}
