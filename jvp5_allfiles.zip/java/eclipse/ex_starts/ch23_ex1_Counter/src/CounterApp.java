public class CounterApp {
    
    // Use these constants as the starting values for the two counter threads
    public static final int ODD = 1;
    public static final int EVEN = 2;
    
    public static void main(String[] args) {
        System.out.println("main started.");
        System.out.println("main finished.");
    }
    
}
