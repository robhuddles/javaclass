public interface Displayable {
    String getDisplayText();
}
