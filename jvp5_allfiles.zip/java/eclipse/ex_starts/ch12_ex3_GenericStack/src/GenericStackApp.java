public class GenericStackApp {

    public static void main(String[] args) {

    }
    
}
