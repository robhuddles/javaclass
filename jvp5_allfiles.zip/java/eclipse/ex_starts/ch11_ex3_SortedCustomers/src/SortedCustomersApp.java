import java.util.Arrays;

public class SortedCustomersApp {

    public static void main(String[] args) {

    }
}
