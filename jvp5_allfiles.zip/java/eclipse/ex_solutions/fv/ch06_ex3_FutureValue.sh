#!/bin/bash

# Change to the directory that stores the JAR file
cd /murach/java/dist/fv

# Use the java command to run the JAR file
java -jar ch06_ex3_FutureValue.jar