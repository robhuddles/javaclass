DELETE FROM Products
WHERE ProductCode = 'test'
