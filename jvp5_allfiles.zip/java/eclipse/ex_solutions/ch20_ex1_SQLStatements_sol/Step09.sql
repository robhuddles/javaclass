SELECT Description, Price
FROM Products
ORDER BY Price DESC