SELECT * 
FROM Products
WHERE ProductCode = 'jscr'