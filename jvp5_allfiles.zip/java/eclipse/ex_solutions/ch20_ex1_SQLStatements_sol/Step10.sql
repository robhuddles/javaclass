INSERT INTO Products (ProductCode, Description, Price)
VALUES ('test', 'Murach''s Test', 99.99)
