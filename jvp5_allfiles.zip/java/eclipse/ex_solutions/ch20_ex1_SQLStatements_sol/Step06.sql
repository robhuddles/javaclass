SELECT * 
FROM Products
WHERE ProductCode = 'java'